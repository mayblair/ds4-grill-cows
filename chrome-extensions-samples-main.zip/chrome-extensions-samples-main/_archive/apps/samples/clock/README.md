<a target="_blank" href="https://chrome.google.com/webstore/detail/lhfiglpmnendbchimlikaeachppfonmm">![Try it now in CWS](https://raw.github.com/GoogleChrome/chrome-extensions-samples/main/_archive/apps/tryitnowbutton.png "Click here to install this sample from the Chrome Web Store")</a>


# Clock

A widget-like application that provides a world clock, an alarm, a timer and a stopwatch.

## APIs

* [Sync Storage API](http://developer.chrome.com/apps/storage)
* [Runtime](https://developer.chrome.com/docs/extensions/reference/app_runtime)
* [Window](https://developer.chrome.com/docs/extensions/reference/app_window)


## Screenshot
![screenshot](/_archive/apps/samples/clock/assets/screenshot_1280_800.png)

