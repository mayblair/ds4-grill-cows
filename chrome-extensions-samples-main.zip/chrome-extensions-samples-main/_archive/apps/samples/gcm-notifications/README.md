<a target="_blank" href="https://chrome.google.com/webstore/detail/gpededflkpcoehfjpdecdkoiagajloin">![Try it now in CWS](https://raw.github.com/GoogleChrome/chrome-extensions-samples/main/_archive/apps/tryitnowbutton.png "Click here to install this sample from the Chrome Web Store")</a>


# GCM Notifications Sample

Demonstrates the capability to receive the push messages from Google Cloud Messaging (GCM) and show notifications.

## APIs

* [gcm](https://developer.chrome.com/apps/gcm)
* [storage](https://developer.chrome.com/apps/storage)
* [notifications](https://developer.chrome.com/apps/notifications)


## Screenshot
![screenshot](/_archive/apps/samples/gcm-notifications/assets/screenshot_1280_800.png)
