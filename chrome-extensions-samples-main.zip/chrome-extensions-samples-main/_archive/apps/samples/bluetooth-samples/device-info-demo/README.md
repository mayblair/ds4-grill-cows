<a target="_blank" href="https://chrome.google.com/webstore/detail/dblimghcclaakknbpajckcamddhjaaai">![Try it now in CWS](https://raw.github.com/GoogleChrome/chrome-extensions-samples/main/_archive/apps/tryitnowbutton.png "Click here to install this sample from the Chrome Web Store")</a>


Bluetooth Low-Energy Device Information Service Demo
====================================================

This sample demonstrates how an app can communicate with the GATT based Device
Information Service on a Bluetooth Low Energy peripheral using the
chrome.bluetoothLowEnergy API.


## Screenshot
![screenshot](/_archive/apps/samples/bluetooth-samples/device-info-demo/assets/screenshot_1280_800.png)
