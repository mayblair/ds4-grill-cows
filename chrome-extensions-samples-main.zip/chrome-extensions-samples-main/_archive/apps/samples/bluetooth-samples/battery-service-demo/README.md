<a target="_blank" href="https://chrome.google.com/webstore/detail/kllncpgahapecnfkhefffabcemaknamh">![Try it now in CWS](https://raw.github.com/GoogleChrome/chrome-extensions-samples/main/_archive/apps/tryitnowbutton.png "Click here to install this sample from the Chrome Web Store")</a>


Bluetooth Low-Energy Battery Service Demo
=========================================

This sample demonstrates how an app can read the battery level of a Bluetooth
Low Energy peripheral using the chrome.bluetoothLowEnergy API to communicate
with the Generic Attribute Profile (GATT) based Battery Service.


## Screenshot
![screenshot](/_archive/apps/samples/bluetooth-samples/battery-service-demo/assets/screenshot_1280_800.png)
