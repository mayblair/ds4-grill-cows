<a target="_blank" href="https://chrome.google.com/webstore/detail/lidepfgfmameopopgagobnpndcnfgbnk">![Try it now in CWS](https://raw.github.com/GoogleChrome/chrome-extensions-samples/main/_archive/apps/tryitnowbutton.png "Click here to install this sample from the Chrome Web Store")</a>


# Media Gallery

This is a sample application that uses the [media gallery](http://developer.chrome.com/apps/mediaGalleries) API to read and show user's media without requiring direct filesystem permission.

## APIs

* [Media gallery](http://developer.chrome.com/apps/mediaGalleries)
* [Runtime](https://developer.chrome.com/docs/extensions/reference/app_runtime)
* [Window](https://developer.chrome.com/docs/extensions/reference/app_window)


## Screenshot
![screenshot](/_archive/apps/samples/media-gallery/assets/screenshot_1280_800.png)

